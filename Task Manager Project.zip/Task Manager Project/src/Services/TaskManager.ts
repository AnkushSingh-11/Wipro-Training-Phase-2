import { Task } from "../model/task";

export class TaskManager {
  private tasks: Task[] = [];
  private taskIdCounter: number = 1;

  addTask(title: string, description: string): Task {
    const newTask = new Task(this.taskIdCounter++, title, description);
    this.tasks.push(newTask);
    return newTask;
  }


  getTasks(): Task[] {
    return this.tasks;
  }

  completeTask(id: number): boolean {
    const task = this.tasks.find((task) => task.id === id);
    if (!task) {
      console.error(`Task with ID ${id} not found.`);
      return false;
    }
    task.isCompleted = true;
    return true;
  }
}
