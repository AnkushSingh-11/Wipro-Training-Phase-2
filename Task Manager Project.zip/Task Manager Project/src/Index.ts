import { TaskManager } from "./Services/TaskManager";

const taskManager = new TaskManager();

try {
  const task1 = taskManager.addTask("Learn TypeScript", "Understand the basics of TypeScript.");
  const task2 = taskManager.addTask("Build a project", "Create a task manager using TypeScript.");

  console.log("Tasks after addition:", taskManager.getTasks());

  if (taskManager.completeTask(1)) {
    console.log("Task 1 marked as complete.");
  }

  console.log("Tasks after completion update:", taskManager.getTasks());
} catch (error) {
  console.error("An unexpected error occurred:", error);
}
