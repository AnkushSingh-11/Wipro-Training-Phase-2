# Task Manager Project

A simple task manager implemented in TypeScript.

## Project Structure

